package Primer_trimestre;

import java.util.*;

public class Ejercicio_01 {

	public static void main(String[] args) {		
		
		
		Scanner nacer = new Scanner (System.in);
		
		int a, b;
		
		System.out.println("Pon el dia que naciste:");
		a = nacer.nextInt();
		System.out.println("Pon el mes que naciste:");
		b = nacer.nextInt();
		
		
		if (b==1) {
			if ((a>=1)&&(a<=20)){
				System.out.println("Su horóscopo es Capricornio.");
			}
			else if((a>20)&&(a<=31)) {
				System.out.println("Su horóscopo es Acuario.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==2) {
			if ((a>=1)&&(a<=19)){
				System.out.println("Su horóscopo es Acuario.");
			}
			else if((a>19)&&(a<=29)) {
				System.out.println("Su horóscopo es Piscis.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==3) {
			if ((a>=1)&&(a<=20)){
				System.out.println("Su horóscopo es Piscis.");
			}
			else if((a>20)&&(a<=31)) {
				System.out.println("Su horóscopo es Aries.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==4) {
			if ((a>=1)&&(a<=20)){
				System.out.println("Su horóscopo es Aries.");
			}
			else if((a>20)&&(a<=30)) {
				System.out.println("Su horóscopo es Tauro.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==5) {
			if ((a>=1)&&(a<=21)){
				System.out.println("Su horóscopo es Tauro.");
			}
			else if((a>21)&&(a<=31)) {
				System.out.println("Su horóscopo es Gémesis.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==6) {
			if ((a>=1)&&(a<=22)){
				System.out.println("Su horóscopo es Gémesis.");
			}
			else if((a>22)&&(a<=30)) {
				System.out.println("Su horóscopo es Cáncer.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==7) {
			if ((a>=1)&&(a<=22)){
				System.out.println("Su horóscopo es Cáncer.");
			}
			else if((a>22)&&(a<=31)) {
				System.out.println("Su horóscopo es Leo.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==8) {
			if ((a>=1)&&(a<=22)){
				System.out.println("Su horóscopo es Leo.");
			}
			else if((a>22)&&(a<=31)) {
				System.out.println("Su horóscopo es Virgo.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==9) {
			if ((a>=1)&&(a<=23)){
				System.out.println("Su horóscopo es Virgo.");
			}
			else if((a>23)&&(a<=30)) {
				System.out.println("Su horóscopo es Libra.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==10) {
			if ((a>=1)&&(a<=22)){
				System.out.println("Su horóscopo es Libra.");
			}
			else if((a>22)&&(a<=31)) {
				System.out.println("Su horóscopo es Escorpio.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==11) {
			if ((a>=1)&&(a<=22)){
				System.out.println("Su horóscopo es Escorpio.");
			}
			else if((a>22)&&(a<=30)) {
				System.out.println("Su horóscopo es Sagitario.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		
		else if (b==12) {
			if ((a>=1)&&(a<=21)){
				System.out.println("Su horóscopo es Sagitario.");
			}
			else if((a>21)&&(a<=31)) {
				System.out.println("Su horóscopo es Capricornio.");
			}
			else {
				System.out.println("Has puesto un dia incorrecto.");
			}
		}
		else {
			System.out.println("Has puesto mal el mes porque solo hay 12 meses y has puesto el " + b);
		}
		
		
		
	nacer.close();	
		
	}

}